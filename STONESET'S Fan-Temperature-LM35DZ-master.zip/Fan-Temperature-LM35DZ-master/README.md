# Fan Temperature LM35DZ
